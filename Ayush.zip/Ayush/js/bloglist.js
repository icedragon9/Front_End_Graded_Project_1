function openModal(){
	document.getElementById("myModalnew").style.display="block"
}
function closeModal(){
	document.getElementById("myModalnew").style.display="none"
}